package com.microservices.hotelservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
